us = '123\n456\n789'
for i in us.split('\n'):
    print(i)