count=1
old=$(cat sha_log_info.txt)
file="log_info.txt"
cat $file | while read line
do
    nam="$("$line" | cut --complement -c 4-)"
    if [[ *$nam*!=$old ]]
    then
      { IFS= read log pass;} <<< $line
      shapass=$($pass | sha256sum | cut -d " " -f 1)
      echo "$log $shapass">> sha_log_info.txt
    fi
done