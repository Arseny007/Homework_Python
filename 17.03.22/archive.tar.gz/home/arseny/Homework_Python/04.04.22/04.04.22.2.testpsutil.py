i, j = 0, 1
while True:
    i += 100
    while True:
        j *= 5
        h = i**2 * j