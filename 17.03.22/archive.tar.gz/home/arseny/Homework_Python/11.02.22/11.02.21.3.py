a = 'texxxt'
b = 10
print(f'text: {a}, num: = {b}')