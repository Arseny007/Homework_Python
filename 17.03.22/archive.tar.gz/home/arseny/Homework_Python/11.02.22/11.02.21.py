# a, b = 'ab', 'bc'
# print(a + b)
# a = 'io[o'
# number = 10
# print('Text: %s'%(a))
# print('Number: %d'%x)
#  s - string
#  d - decimal
#  x - hex
#  o - x8
#  b - binary
#  f - float

# print('{1:}text'.format(number, a))
# '{индекс:      *^30f}'.format('a')
# print('{0: *^30f}'.format('a'))
# >>> '****a****'
# 30 - выделенное место
# ^ - форматирование по центру, > - справа, < - слева
# nums = [0, 10, 20]
# print('fisrt: {0[0]:} second: {0[1]}'.format(nums))
# 1) 'cnhjrf{0:!^30d}'.format(values)
# 2) 'text %s %s'%(value1, value2)
# 3) f'{value}'
# 1
# 1
# 1
# ДЗ - написать функцию, которая принимает список аргументов
# выравнивание ('center', 'left', 'right')
# символ заполнения
# место
# например
# func([1,2,3], 'center', '*', 9)
# >>> ****1****
# ****2****
# ****3****
