p:str
p = 10
p:str = 10