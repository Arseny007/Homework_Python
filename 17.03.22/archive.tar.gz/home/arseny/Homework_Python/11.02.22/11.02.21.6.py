def ras(title, tale):
    return '{0: ^100}\n \t{1:}'.format(title.upper(), tale)

print(ras('mytale', 'fghjlghfgvbbnmjkhgbnmjfgbnkjhghfvbnmkjhjgvbnmkhgvbnmjhjgbnmhgvbb'))