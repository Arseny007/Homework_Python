name:str
name = 10
name:str = 10