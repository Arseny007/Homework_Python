# import itertools

# numbers = dict()
# numbers['1'] = '124'
# numbers['2'] = '2135'
# numbers['3'] = '326'
# numbers['4'] = '4157'
# numbers['5'] = '52468'
# numbers['6'] = '6359'
# numbers['7'] = '748'
# numbers['8'] = '87590'
# numbers['9'] = '986'
# numbers['0'] = '08'

# def safe(password):
#     res = list()
#     nums = password.split(' ')
#     for num in nums:
#         res.append(numbers[]])
#     return list(itertools.product(res[0], res[1], res[2], res[3]))

# code = input('enter code: ')
# print(safe(code))